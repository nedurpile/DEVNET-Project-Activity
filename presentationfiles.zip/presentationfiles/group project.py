import urllib.parse
import requests
from colorama import Fore, Back, Style

main_api = "https://www.mapquestapi.com/directions/v2/route?"
key = "AqEEoHjEY6kvH0ZqtI8jxEjRtp3GkHUd"
cont = "yes"
while cont.lower() == "yes":
    unit_type = input("Include Metric Measurements? (yes/no) ")
    name = input("Your Name: ")
    orig = input("Starting Location: ")
    if orig == "quit" or orig == "q":
        break
    dest = input("Destination: ")
    if dest == "quit" or dest == "q":
        break
    url = main_api + urllib.parse.urlencode({"key": key, "from":orig, "to":dest})
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    print("URL: " + (url))
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    json_data = requests.get(url).json()
    json_status = json_data["info"]["statuscode"]
    if json_status == 0:
        print("API Status: " + str(json_status) + " = A successful route call.\n")
        print(name + "'s Trip to " + str(Fore.RED + (dest)))
        print(Style.RESET_ALL + "=================================================")
        print("| Directions from " + str(Fore.BLUE + (orig)) + (Fore.WHITE + " to ") + str(Fore.RED + (dest)) + str(Fore.WHITE + "\t\t|"))
        print(Style.RESET_ALL + "=================================================")
        print("| Trip Duration:   " + Fore.CYAN + (json_data["route"]["formattedTime"]) + Style.RESET_ALL + "\t\t\t|")
        if unit_type == "yes":
            print("| Miles:           " + Fore.LIGHTMAGENTA_EX + str(json_data["route"]["distance"]) + Style.RESET_ALL + "\t\t\t|" + "\n| Kilometers:      " + Fore.GREEN + str((json_data["route"]["distance"])*1.61) + Style.RESET_ALL + "\t\t\t|" + Style.RESET_ALL)
        else:
            print("| Miles:           " + str(json_data["route"]["distance"]) + "\t\t\t|")
        print("=================================================")
        for each in json_data["route"]["legs"][0]["maneuvers"]:
            if unit_type == "yes":
                print((each["narrative"]) + " (" + str("{:.2f}".format((each["distance"])*1.61) + " km)"))
            else:
                print((each["narrative"]))
        print("=================================================")
        print("Have a great trip! ☺\n")
    elif json_status == 402:
        print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
        print("Status Code: " + str(json_status) + "; Invalid user inputs for one or both locations.")
        print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n")
    elif json_status == 611:
        print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
        print("Status Code: " + str(json_status) + "; Missing an entry for one or both locations.")
        print("**********************************************\n")
    else:
        print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
        print("For Staus Code: " + str(json_status) + "; Refer to:")
        print("https://developer.mapquest.com/documentation/directions-api/status-codes")
        print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n")
    cont = input("Continue? (yes/no): ")

